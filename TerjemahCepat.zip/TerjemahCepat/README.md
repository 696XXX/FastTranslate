# Terjemah Cepat v2

Tombol mengambang yang menerjemahkan apa pun di layar lewat mesin sendiri: tangkap layar (MediaProjection) → OCR (ML Kit) → terjemah di HP (ML Kit Translate). Tidak memakai layanan Aksesibilitas, jadi tidak perlu melewati blokir keamanan khusus untuk fitur itu.

Catatan jujur: aplikasi ini tetap dipasang manual (di luar Play Store), jadi Android/Play Protect akan tetap menampilkan satu peringatan "sumber tidak dikenal" saat pemasangan pertama — itu normal untuk semua APK sideload, bukan hanya aplikasi ini, dan tidak saya buatkan cara untuk menyembunyikannya karena itu sama dengan melewati pemindaian malware. Cara sah menghilangkannya sepenuhnya adalah publikasi lewat Google Play (lolos review).

Hanya ada satu paket proyek (open source) di zip ini — tidak ada versi "terenkripsi" terpisah, dengan alasan di atas. Kalau nanti dipublikasikan ke Play Store, R8/ProGuard (`isMinifyEnabled = true`) bisa dipakai untuk mempersulit pembacaan kode, itu cara yang sah dan bisa ditambahkan saat itu.

## Build APK

**GitHub Actions (dari HP, tanpa PC):** upload `TerjemahCepat.zip` ini ke repo baru, tambahkan file `.github/workflows/build.yml` seperti sebelumnya (ekstrak zip lalu `gradle assembleDebug`), jalankan di tab Actions, unduh artifact.

**Android Studio:** File > Open > folder ini > Build > Build APK(s).

## Pasang & aktifkan

1. Pasang APK → buka aplikasi → ikuti 3 langkah onboarding (autostart, izin tampil di atas aplikasi lain, gabung Discord).
2. Di layar utama, nyalakan switch "Aktifkan". Akan muncul dialog sistem minta izin rekam layar — izinkan. Ini dialog bawaan Android, muncul setiap aplikasi baru dijalankan ulang (bukan sesuatu yang disembunyikan).
3. Pilih bahasa asal/tujuan, atur ukuran & transparansi tombol sesuai selera.
4. Ketuk tombol biru di layar mana pun untuk menerjemahkan.

## Iklan

AdMob App ID, Banner Ad Unit ID, dan App Open Ad Unit ID sudah ditaruh di `app/src/main/res/values/strings.xml` — ganti di sana saja kalau suatu saat berubah, tidak perlu menyentuh kode Kotlin.

## Kalau build gagal

Kirim pesan error dari tab Actions (bagian "Build"). Kombinasi ML Kit + AdMob kadang butuh penyesuaian versi dependency kecil; saya bisa perbaiki begitu tahu pesan errornya.
