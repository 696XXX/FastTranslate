package com.azam.terjemahcepat

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val NAME = "prefs"

    const val KEY_ENABLED = "enabled"
    const val KEY_ONBOARD_DONE = "onboard_done"
    const val KEY_BTN_SIZE = "btn_size_dp"
    const val KEY_BTN_ALPHA = "btn_alpha"
    const val KEY_RES_ALPHA = "res_alpha"
    const val KEY_SRC = "src_lang"
    const val KEY_TGT = "tgt_lang"
    const val KEY_POS_X = "pos_x"
    const val KEY_POS_Y = "pos_y"

    const val DEF_BTN_SIZE = 56
    const val DEF_BTN_ALPHA = 90
    const val DEF_RES_ALPHA = 92
    const val DEF_SRC = "auto"
    const val DEF_TGT = "id"

    /** Bahasa asal. "auto" memakai deteksi bahasa otomatis untuk huruf Latin. */
    val SOURCES: List<Pair<String, String>> = listOf(
        "auto" to "Otomatis (huruf Latin)",
        "ja" to "Jepang",
        "zh" to "Mandarin",
        "ko" to "Korea"
    )

    val TARGETS: List<Pair<String, String>> = listOf(
        "id" to "Indonesia",
        "en" to "Inggris",
        "ja" to "Jepang",
        "ko" to "Korea",
        "zh" to "Mandarin",
        "es" to "Spanyol",
        "fr" to "Prancis",
        "de" to "Jerman",
        "pt" to "Portugis",
        "ar" to "Arab",
        "ru" to "Rusia"
    )

    fun get(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun labelOf(list: List<Pair<String, String>>, code: String): String =
        list.firstOrNull { it.first == code }?.second ?: code

    fun indexOf(list: List<Pair<String, String>>, code: String): Int =
        list.indexOfFirst { it.first == code }.let { if (it < 0) 0 else it }
}
