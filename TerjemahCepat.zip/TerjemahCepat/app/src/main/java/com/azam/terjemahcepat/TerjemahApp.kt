package com.azam.terjemahcepat

import android.app.Activity
import android.app.Application
import android.os.Bundle
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.appopen.AppOpenAd
import java.util.Date

class TerjemahApp : Application() {
    override fun onCreate() {
        super.onCreate()
        MobileAds.initialize(this) {}
    }
}

/**
 * Memuat dan menampilkan App Open Ad. Dipanggil dari MainActivity setiap
 * aplikasi dibuka. Hanya tampil sekali per proses (tidak berulang saat
 * layar diputar atau kembali dari dialog izin), dan cache iklan kedaluwarsa
 * setelah 4 jam sesuai pedoman Google.
 */
object AppOpenAdManager {
    private var ad: AppOpenAd? = null
    private var loadTime: Long = 0L
    private var loading = false
    private var shownThisProcess = false

    private fun isAdAvailable() = ad != null && Date().time - loadTime < 4 * 60 * 60 * 1000

    fun showOnAppOpen(activity: Activity) {
        if (shownThisProcess) return
        shownThisProcess = true

        if (isAdAvailable()) {
            show(activity)
        } else {
            load(activity) { show(activity) }
        }
    }

    private fun load(activity: Activity, onLoaded: () -> Unit) {
        if (loading || isAdAvailable()) return
        loading = true
        AppOpenAd.load(
            activity,
            activity.getString(R.string.admob_app_open_unit_id),
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(loadedAd: AppOpenAd) {
                    ad = loadedAd
                    loadTime = Date().time
                    loading = false
                    onLoaded()
                }

                override fun onAdFailedToLoad(error: com.google.android.gms.ads.LoadAdError) {
                    loading = false
                }
            }
        )
    }

    private fun show(activity: Activity) {
        val a = ad
        if (a == null || !isAdAvailable()) return
        a.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                ad = null
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                ad = null
            }
        }
        a.show(activity)
    }
}
