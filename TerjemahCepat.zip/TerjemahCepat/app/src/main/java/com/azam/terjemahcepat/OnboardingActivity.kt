package com.azam.terjemahcepat

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Alur 3 langkah saat pertama kali membuka aplikasi: mulai otomatis di
 * latar belakang, izin tampil di atas aplikasi lain, lalu gabung Discord.
 * Pada kunjungan berikutnya langsung diteruskan ke MainActivity.
 */
class OnboardingActivity : Activity() {

    private var step = 0
    private var density = 1f
    private fun dp(v: Int) = (v * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density

        if (Prefs.get(this).getBoolean(Prefs.KEY_ONBOARD_DONE, false)) {
            goToMain()
            return
        }
        render()
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun finishOnboarding() {
        Prefs.get(this).edit().putBoolean(Prefs.KEY_ONBOARD_DONE, true).apply()
        goToMain()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F1F3F4"))
            setPadding(dp(28), dp(48), dp(28), dp(28))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        root.addView(dots())
        root.addView(spacer(24))

        when (step) {
            0 -> buildStep(
                root,
                title = "Langkah 1 — Mulai otomatis di latar belakang",
                body = "Supaya tombol mengambang tetap aktif walau aplikasi ditutup, izinkan Terjemah Cepat berjalan otomatis di latar belakang dan kecualikan dari penghematan baterai.",
                actionLabel = "Buka Pengaturan",
                action = { openAutostart() }
            )
            1 -> buildStep(
                root,
                title = "Langkah 2 — Izinkan tampil di atas aplikasi lain",
                body = "Izin ini dipakai untuk menampilkan tombol mengambang dan kotak hasil terjemahan di layar. Tanpa izin ini tombol tidak bisa muncul.",
                actionLabel = "Buka Pengaturan",
                action = { openOverlaySettings() }
            )
            else -> buildStep(
                root,
                title = "Langkah 3 — Gabung komunitas Discord",
                body = "Dapatkan info update, laporkan kendala, dan diskusi langsung dengan pengembang di komunitas Discord Terjemah Cepat.",
                actionLabel = "Gabung Discord & Lanjut",
                action = { joinDiscordThenFinish() }
            )
        }

        setContentView(root)
    }

    private fun buildStep(
        root: LinearLayout,
        title: String,
        body: String,
        actionLabel: String,
        action: () -> Unit
    ) {
        root.addView(TextView(this).apply {
            text = title
            textSize = 22f
            setTextColor(Color.parseColor("#202124"))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = body
            textSize = 15f
            setTextColor(Color.parseColor("#5F6368"))
            setPadding(0, dp(14), 0, 0)
        })
        root.addView(spacer(28))
        root.addView(Button(this).apply {
            text = actionLabel
            isAllCaps = false
            setBackgroundResource(R.drawable.btn_primary)
            setTextColor(Color.WHITE)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
            )
        })
        if (step < 2) {
            root.addView(spacer(12))
            root.addView(TextView(this).apply {
                text = "Lewati, lanjut ke langkah berikutnya"
                textSize = 14f
                setTextColor(Color.parseColor("#1A73E8"))
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { step++; render() }
            })
        }
    }

    private fun dots(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        for (i in 0..2) {
            row.addView(android.view.View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply {
                    marginStart = dp(4); marginEnd = dp(4)
                }
                setBackgroundColor(
                    Color.parseColor(if (i == step) "#1A73E8" else "#C4C7C5")
                )
            })
        }
        return row
    }

    private fun spacer(h: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun openAutostart() {
        val intents = listOf(
            Intent().setComponent(
                ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
            ),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        )
        for (i in intents) {
            try { startActivity(i); return } catch (_: Exception) {}
        }
        Toast.makeText(this, "Pengaturan ini tidak tersedia di HP kamu.", Toast.LENGTH_SHORT).show()
    }

    private fun openOverlaySettings() {
        try {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } catch (_: Exception) {
            Toast.makeText(this, "Tidak bisa membuka pengaturan ini.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun joinDiscordThenFinish() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.discord_url))))
        } catch (_: Exception) {
        }
        finishOnboarding()
    }
}
