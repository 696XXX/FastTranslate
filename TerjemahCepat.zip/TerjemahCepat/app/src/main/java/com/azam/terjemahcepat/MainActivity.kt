package com.azam.terjemahcepat

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

class MainActivity : Activity() {

    companion object {
        private const val REQ_OVERLAY = 1001
        private const val REQ_CAPTURE = 1002
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var statusDot: TextView
    private lateinit var switchOn: Switch
    private var density = 1f

    private fun dp(v: Int) = (v * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        density = resources.displayMetrics.density

        if (!prefs.getBoolean(Prefs.KEY_ONBOARD_DONE, false)) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish()
            return
        }

        buildUi()
        AppOpenAdManager.showOnAppOpen(this)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F1F3F4"))
        }

        outer.addView(header())

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        content.addView(statusCard())
        content.addView(spacer(14))
        content.addView(appearanceCard())
        content.addView(spacer(14))
        content.addView(languageCard())
        content.addView(spacer(14))
        content.addView(systemCard())
        content.addView(spacer(14))
        content.addView(communityCard())
        content.addView(spacer(20))

        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        outer.addView(bannerAd())

        setContentView(outer)
    }

    private fun header(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Color.parseColor("#1A73E8"))
        setPadding(dp(20), dp(26), dp(20), dp(18))
        addView(TextView(this@MainActivity).apply {
            text = "Terjemah Cepat"
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        addView(TextView(this@MainActivity).apply {
            text = "Tombol mengambang • OCR & terjemah offline"
            textSize = 13f
            setTextColor(Color.parseColor("#D6E4FF"))
            setPadding(0, dp(2), 0, 0)
        })
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundResource(R.drawable.card_bg)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        elevation = 2 * density
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    private fun statusCard(): LinearLayout = card().apply {
        val row = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        statusDot = text("", 15f, bold = true)
        row.addView(statusDot, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        switchOn = Switch(this@MainActivity).apply {
            isChecked = TranslateService.isRunning || prefs.getBoolean(Prefs.KEY_ENABLED, false)
            setOnCheckedChangeListener { _, checked -> onToggle(checked) }
        }
        row.addView(switchOn)
        addView(row)

        addView(text(
            "Ketuk tombol biru di layar untuk menerjemahkan apa pun yang sedang tampil. Tahan lalu geser untuk memindahkan posisinya.",
            13f, color = "#5F6368"
        ).apply { setPadding(0, dp(8), 0, 0) })
    }

    private fun appearanceCard(): LinearLayout = card().apply {
        addView(text("Tampilan tombol", 16f, bold = true))
        addView(spacer(8))
        addSeek(this, "Ukuran tombol", Prefs.KEY_BTN_SIZE, 40, 84, 2, Prefs.DEF_BTN_SIZE, " dp")
        addSeek(this, "Transparansi tombol", Prefs.KEY_BTN_ALPHA, 30, 100, 5, Prefs.DEF_BTN_ALPHA, "%")
        addSeek(this, "Transparansi kotak hasil", Prefs.KEY_RES_ALPHA, 30, 100, 5, Prefs.DEF_RES_ALPHA, "%")
    }

    private fun languageCard(): LinearLayout = card().apply {
        addView(text("Bahasa", 16f, bold = true))
        addView(spacer(8))
        addView(text("Bahasa asal", 13f, color = "#5F6368"))
        addView(langSpinner(Prefs.SOURCES, Prefs.KEY_SRC, Prefs.DEF_SRC))
        addView(spacer(10))
        addView(text("Bahasa tujuan", 13f, color = "#5F6368"))
        addView(langSpinner(Prefs.TARGETS, Prefs.KEY_TGT, Prefs.DEF_TGT))
    }

    private fun systemCard(): LinearLayout = card().apply {
        addView(text("Pengaturan sistem", 16f, bold = true))
        addView(spacer(8))
        addView(outlineButton("Mulai otomatis di latar belakang") { openAutostart() })
        addView(spacer(8))
        addView(outlineButton("Izinkan tampil di atas aplikasi lain") { openOverlaySettings() })
    }

    private fun communityCard(): LinearLayout = card().apply {
        addView(text("Komunitas & update", 16f, bold = true))
        addView(spacer(8))
        addView(filledButton("Gabung Discord", "#5865F2") {
            safeOpen(getString(R.string.discord_url))
        })
        addView(spacer(8))
        addView(filledButton("Subscribe YouTube", "#FF0000") {
            safeOpen(getString(R.string.youtube_url))
        })
    }

    private fun bannerAd(): FrameLayout {
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val adView = AdView(this)
        adView.setAdSize(AdSize.BANNER)
        adView.adUnitId = getString(R.string.admob_banner_unit_id)
        frame.addView(adView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))
        adView.loadAd(AdRequest.Builder().build())
        return frame
    }

    // ---------------------------------------------------------------- aksi

    private fun onToggle(checked: Boolean) {
        if (checked) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan \"Tampil di atas aplikasi lain\" dulu.", Toast.LENGTH_LONG).show()
                switchOn.isChecked = false
                openOverlaySettings()
                return
            }
            requestCapture()
        } else {
            stopService(Intent(this, TranslateService::class.java).apply { action = TranslateService.ACTION_STOP })
            prefs.edit().putBoolean(Prefs.KEY_ENABLED, false).apply()
            refreshStatus()
        }
    }

    @Suppress("DEPRECATION")
    private fun requestCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val intent = Intent(this, TranslateService::class.java).apply {
                    action = TranslateService.ACTION_START
                    putExtra(TranslateService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(TranslateService.EXTRA_DATA, data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                else startService(intent)
                prefs.edit().putBoolean(Prefs.KEY_ENABLED, true).apply()
            } else {
                Toast.makeText(this, "Izin tangkap layar dibatalkan.", Toast.LENGTH_SHORT).show()
                switchOn.isChecked = false
            }
            refreshStatus()
        }
    }

    private fun refreshStatus() {
        val active = TranslateService.isRunning
        statusDot.text = if (active) "● Aktif" else "○ Nonaktif"
        statusDot.setTextColor(Color.parseColor(if (active) "#188038" else "#D93025"))
        if (::switchOn.isInitialized) switchOn.isChecked = active
    }

    private fun openAutostart() {
        val intents = listOf(
            Intent().setComponent(
                ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
            ),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        )
        for (i in intents) {
            try { startActivity(i); return } catch (_: Exception) {}
        }
        Toast.makeText(this, "Pengaturan ini tidak tersedia di HP kamu.", Toast.LENGTH_SHORT).show()
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (_: Exception) {
            Toast.makeText(this, "Tidak bisa membuka pengaturan ini.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun safeOpen(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {
            Toast.makeText(this, "Tidak bisa membuka tautan.", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- komponen kecil

    private fun text(s: String, sizeSp: Float, bold: Boolean = false, color: String = "#202124") =
        TextView(this).apply {
            text = s
            textSize = sizeSp
            setTextColor(Color.parseColor(color))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun filledButton(label: String, hex: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.parseColor(hex))
            cornerRadius = 12 * density
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50))
    }

    private fun outlineButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.parseColor("#1A73E8"))
        setBackgroundResource(R.drawable.btn_outline)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48))
    }

    private fun spacer(h: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun addSeek(
        root: LinearLayout, label: String, key: String,
        min: Int, max: Int, step: Int, def: Int, unit: String
    ) {
        val current = prefs.getInt(key, def).coerceIn(min, max)
        val caption = text("$label: $current$unit", 13f, color = "#5F6368")
        val bar = SeekBar(this).apply {
            this.max = (max - min) / step
            progress = (current - min) / step
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val value = min + p * step
                    caption.text = "$label: $value$unit"
                    if (fromUser) prefs.edit().putInt(key, value).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(caption)
        root.addView(bar)
        root.addView(spacer(6))
    }

    private fun langSpinner(list: List<Pair<String, String>>, key: String, def: String): Spinner {
        val labels = list.map { it.second }
        return Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels)
            setSelection(Prefs.indexOf(list, prefs.getString(key, def) ?: def))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    prefs.edit().putString(key, list[pos].first).apply()
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
    }
}
