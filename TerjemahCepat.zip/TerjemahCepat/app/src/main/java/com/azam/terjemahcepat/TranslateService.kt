package com.azam.terjemahcepat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Layanan latar depan yang menampilkan tombol mengambang. Saat diketuk:
 * memotret layar lewat MediaProjection, membaca teks dengan ML Kit OCR,
 * menerjemahkannya di HP dengan ML Kit Translate, lalu menampilkan hasilnya
 * sebagai kotak terjemahan di atas teks asli. Tidak memakai layanan
 * Aksesibilitas dan tidak mengirim data ke server mana pun.
 */
class TranslateService : Service() {

    companion object {
        const val ACTION_START = "com.azam.terjemahcepat.START"
        const val ACTION_STOP = "com.azam.terjemahcepat.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"

        private const val CHANNEL_ID = "terjemah_cepat_channel"
        private const val NOTIF_ID = 1001
        private const val AUTO_DISMISS_MS = 9000L

        @Volatile
        var isRunning = false
            private set
    }

    private val wm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val prefs: SharedPreferences by lazy { Prefs.get(this) }
    private val handler = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var button: ImageView? = null
    private var resultView: ResultOverlayView? = null
    private var busy = false
    private var activeTranslator: Translator? = null
    private var activeKey: String = ""

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.KEY_BTN_SIZE || key == Prefs.KEY_BTN_ALPHA) applyButtonStyle()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                teardown()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(NOTIF_ID, buildNotification())
                val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
                val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
                if (data != null) startProjection(resultCode, data)
                isRunning = true
                addButton()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        removeButton()
        removeResult()
        activeTranslator?.close()
        projection?.stop()
        projection = null
        isRunning = false
        super.onDestroy()
    }

    private fun teardown() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        try {
            projection = mgr.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    projection = null
                }
            }, handler)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal mengaktifkan izin tangkap layar.", Toast.LENGTH_LONG).show()
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val mgr = getSystemService(NotificationManager::class.java)
        if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
            mgr.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Terjemah Cepat", NotificationManager.IMPORTANCE_MIN)
            )
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Terjemah Cepat aktif")
            .setContentText("Tombol mengambang siap dipakai")
            .setSmallIcon(R.drawable.ic_translate)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    // ---------------------------------------------------------------- tombol mengambang

    private fun addButton() {
        if (button != null) {
            applyButtonStyle()
            return
        }

        val d = resources.displayMetrics.density
        val slop = ViewConfiguration.get(this).scaledTouchSlop

        val iv = ImageView(this)
        iv.setImageResource(R.drawable.ic_translate)
        iv.contentDescription = "Tombol terjemah mengambang"

        val (sw, sh) = screenSize()
        val size = sizePx()
        val lp = WindowManager.LayoutParams(
            size, size,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt(Prefs.KEY_POS_X, sw - size - (8 * d).toInt()).coerceIn(0, max(0, sw - size))
        lp.y = prefs.getInt(Prefs.KEY_POS_Y, sh / 2).coerceIn(0, max(0, sh - size))

        iv.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY
                        startX = lp.x; startY = lp.y
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                        if (moved) {
                            val (w, h) = screenSize()
                            lp.x = (startX + dx).toInt().coerceIn(0, max(0, w - lp.width))
                            lp.y = (startY + dy).toInt().coerceIn(0, max(0, h - lp.height))
                            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            prefs.edit().putInt(Prefs.KEY_POS_X, lp.x).putInt(Prefs.KEY_POS_Y, lp.y).apply()
                        } else {
                            onButtonTapped()
                        }
                    }
                }
                return true
            }
        })

        try {
            wm.addView(iv, lp)
            button = iv
            applyButtonStyle()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menampilkan tombol: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun sizePx(): Int {
        val dp = prefs.getInt(Prefs.KEY_BTN_SIZE, Prefs.DEF_BTN_SIZE)
        return (dp * resources.displayMetrics.density).toInt()
    }

    private fun applyButtonStyle() {
        val iv = button ?: return
        val d = resources.displayMetrics.density
        val pad = ((prefs.getInt(Prefs.KEY_BTN_SIZE, Prefs.DEF_BTN_SIZE) * 0.25f) * d).toInt()
        iv.setPadding(pad, pad, pad, pad)
        iv.elevation = 6 * d
        val alphaPct = prefs.getInt(Prefs.KEY_BTN_ALPHA, Prefs.DEF_BTN_ALPHA).coerceIn(20, 100)
        val bgAlpha = (255 * (alphaPct / 100f)).toInt()
        iv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(bgAlpha, 0x1A, 0x73, 0xE8))
        }
        val newSize = sizePx()
        val lp = iv.layoutParams as? WindowManager.LayoutParams
        if (lp != null && lp.width != newSize) {
            lp.width = newSize
            lp.height = newSize
            try { wm.updateViewLayout(iv, lp) } catch (_: Exception) {}
        }
    }

    private fun removeButton() {
        val b = button ?: return
        try { wm.removeView(b) } catch (_: Exception) {}
        button = null
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        val m = DisplayMetrics()
        dm.getDisplay(android.view.Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    // ---------------------------------------------------------------- alur terjemah

    private fun onButtonTapped() {
        if (busy) return
        val proj = projection
        if (proj == null) {
            Toast.makeText(this, "Izin tangkap layar belum aktif. Buka aplikasi lalu nyalakan lagi.", Toast.LENGTH_LONG).show()
            return
        }
        busy = true
        removeResult()
        button?.visibility = View.INVISIBLE
        handler.postDelayed({ capture(proj) }, 150)
    }

    private fun capture(proj: MediaProjection) {
        val (w, h) = screenSize()
        val density = resources.displayMetrics.densityDpi
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        var vDisplay: VirtualDisplay? = null

        reader.setOnImageAvailableListener({ r ->
            val image = try { r.acquireLatestImage() } catch (_: Exception) { null }
            if (image == null) {
                cleanupCapture(vDisplay, r)
                failAndRestore("Gagal mengambil gambar layar.")
                return@setOnImageAvailableListener
            }
            try {
                val plane = image.planes[0]
                val rowStride = plane.rowStride
                val pixelStride = plane.pixelStride
                val rowPadding = rowStride - pixelStride * w
                val bmp = Bitmap.createBitmap(
                    w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888
                )
                bmp.copyPixelsFromBuffer(plane.buffer)
                val cropped = if (rowPadding == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, w, h)
                runOcr(cropped)
            } catch (e: Exception) {
                failAndRestore("Gagal memproses gambar layar.")
            } finally {
                image.close()
                cleanupCapture(vDisplay, r)
            }
        }, handler)

        vDisplay = try {
            proj.createVirtualDisplay(
                "TerjemahCepatCapture", w, h, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, handler
            )
        } catch (e: Exception) {
            null
        }
        if (vDisplay == null) {
            reader.close()
            failAndRestore("Gagal menangkap layar.")
        }
    }

    private fun cleanupCapture(vDisplay: VirtualDisplay?, reader: ImageReader) {
        try { reader.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        try { vDisplay?.release() } catch (_: Exception) {}
        try { reader.close() } catch (_: Exception) {}
    }

    private fun runOcr(bmp: Bitmap) {
        val src = prefs.getString(Prefs.KEY_SRC, Prefs.DEF_SRC) ?: Prefs.DEF_SRC
        val recognizer: TextRecognizer = when (src) {
            "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
        val image = InputImage.fromBitmap(bmp, 0)
        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                val blocks = visionText.textBlocks
                    .filter { !it.text.isNullOrBlank() && it.boundingBox != null }
                    .take(40)
                if (blocks.isEmpty()) {
                    failAndRestore("Tidak ada teks terbaca di layar ini.")
                    return@addOnSuccessListener
                }
                resolveSourceLanguage(src, blocks.joinToString("\n") { it.text }) { resolvedSrc ->
                    translateBlocks(resolvedSrc, blocks)
                }
            }
            .addOnFailureListener { failAndRestore("OCR gagal: ${it.message}") }
    }

    private fun resolveSourceLanguage(src: String, sampleText: String, onReady: (String) -> Unit) {
        if (src != "auto") {
            onReady(mlkitCode(src))
            return
        }
        LanguageIdentification.getClient().identifyLanguage(sampleText)
            .addOnSuccessListener { code ->
                if (code == "und") failAndRestore("Bahasa tidak terdeteksi.")
                else onReady(code)
            }
            .addOnFailureListener { onReady("en") }
    }

    private fun mlkitCode(code: String): String = when (code) {
        "zh" -> TranslateLanguage.CHINESE
        "ja" -> TranslateLanguage.JAPANESE
        "ko" -> TranslateLanguage.KOREAN
        else -> code
    }

    private fun translateBlocks(sourceCode: String, blocks: List<com.google.mlkit.vision.text.Text.TextBlock>) {
        val targetPref = prefs.getString(Prefs.KEY_TGT, Prefs.DEF_TGT) ?: Prefs.DEF_TGT
        val targetCode = mlkitCode(targetPref)

        if (sourceCode == targetCode) {
            failAndRestore("Teks sudah dalam bahasa tujuan.")
            return
        }

        val translator = getTranslator(sourceCode, targetCode)
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                translateSequentially(translator, blocks, 0, mutableListOf())
            }
            .addOnFailureListener {
                failAndRestore("Gagal mengunduh model bahasa. Cek koneksi internet.")
            }
    }

    private fun getTranslator(sourceCode: String, targetCode: String): Translator {
        val key = "$sourceCode>$targetCode"
        if (key != activeKey) {
            activeTranslator?.close()
            activeTranslator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(sourceCode)
                    .setTargetLanguage(targetCode)
                    .build()
            )
            activeKey = key
        }
        return activeTranslator!!
    }

    private fun translateSequentially(
        translator: Translator,
        blocks: List<com.google.mlkit.vision.text.Text.TextBlock>,
        index: Int,
        results: MutableList<Pair<Rect, String>>
    ) {
        if (index >= blocks.size) {
            if (results.isEmpty()) failAndRestore("Terjemahan gagal.")
            else showResult(results)
            return
        }
        val block = blocks[index]
        translator.translate(block.text)
            .addOnSuccessListener { translated ->
                results.add(block.boundingBox!! to translated)
                translateSequentially(translator, blocks, index + 1, results)
            }
            .addOnFailureListener {
                translateSequentially(translator, blocks, index + 1, results)
            }
    }

    // ---------------------------------------------------------------- tampilkan hasil

    private fun showResult(items: List<Pair<Rect, String>>) {
        handler.post {
            removeResult()
            val alphaPct = prefs.getInt(Prefs.KEY_RES_ALPHA, Prefs.DEF_RES_ALPHA).coerceIn(30, 100)
            val view = ResultOverlayView(this, items, alphaPct) { dismissResult() }

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            try {
                wm.addView(view, lp)
                resultView = view
            } catch (_: Exception) {
            }
            button?.visibility = View.VISIBLE
            busy = false
            handler.postDelayed({ dismissResult() }, AUTO_DISMISS_MS)
        }
    }

    private fun dismissResult() {
        handler.post { removeResult() }
    }

    private fun removeResult() {
        val v = resultView ?: return
        try { wm.removeView(v) } catch (_: Exception) {}
        resultView = null
    }

    private fun failAndRestore(message: String) {
        handler.post {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            button?.visibility = View.VISIBLE
            busy = false
        }
    }
}

/**
 * Kotak terjemahan yang digambar tepat di atas posisi teks asli.
 * Ketuk di mana pun untuk menutup lebih awal.
 */
private class ResultOverlayView(
    context: Context,
    private val items: List<Pair<Rect, String>>,
    alphaPct: Int,
    private val onDismiss: () -> Unit
) : FrameLayout(context) {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb((255 * (alphaPct / 100f)).toInt(), 0x12, 0x12, 0x12)
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 14f * resources.displayMetrics.scaledDensity
    }

    init {
        setWillNotDraw(false)
        isClickable = true
        setOnClickListener { onDismiss() }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for ((rect, text) in items) {
            val pad = 10f
            val width = max(rect.width().toFloat() - pad * 2, 40f)
            val layout = StaticLayout.Builder
                .obtain(text, 0, text.length, textPaint, width.toInt())
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .build()

            val boxRect = RectF(
                rect.left.toFloat(),
                rect.top.toFloat(),
                rect.left + width + pad * 2,
                rect.top + layout.height + pad * 2
            )
            canvas.drawRoundRect(boxRect, 10f, 10f, bgPaint)
            canvas.save()
            canvas.translate(boxRect.left + pad, boxRect.top + pad)
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
