plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.azam.terjemahcepat"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.azam.terjemahcepat"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"

        // Poco M6 Pro memakai arm64; armeabi-v7a untuk jaga-jaga. Memperkecil ukuran APK.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // Kunci tetap supaya update berikutnya bisa dipasang menimpa versi lama
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "/META-INF/DEPENDENCIES"
        }
    }
}

dependencies {
    // OCR (model ikut di dalam APK, jalan offline)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")

    // Terjemahan di HP (model bahasa diunduh sekali) dan deteksi bahasa
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")

    // Iklan AdMob (Banner + App Open) — mendukung biaya pengembangan
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
